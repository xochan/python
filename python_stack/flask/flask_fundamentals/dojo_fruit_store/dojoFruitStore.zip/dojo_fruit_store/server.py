from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe'
@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/show', methods=['POST'])         
def show():
    print(request.form)
    session['strawberry'] = request.form['strawberry']
    session['raspberry'] = request.form['raspberry']
    session['apple'] = request.form['apple']
    session['firstname'] = request.form['first_name']
    session['lastname'] = request.form['last_name']
    session['studentid'] = request.form['student_id']
    session['customername'] = session['firstname'] + ' ' + session['lastname']
    session['count'] = int(session['strawberry']) + int(session['raspberry']) + int(session['apple'])
    print('customername')
    return redirect('/checkout')

@app.route('/checkout')
def checkout():
    return render_template("checkout.html",straw = session['strawberry'], rasp = session['raspberry'], apple = session['apple'], \
    first = session['firstname'], last = session['lastname'], id = session['studentid'], customer = session['customername'], count = str(session['count']))

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    