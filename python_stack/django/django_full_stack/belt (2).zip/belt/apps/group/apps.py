from django.apps import AppConfig


class GroupConfig(AppConfig):
    name = 'group'
