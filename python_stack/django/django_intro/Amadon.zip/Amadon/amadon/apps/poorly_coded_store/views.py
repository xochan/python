from django.shortcuts import render, redirect
from .models import Order, Product

def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    request.session['quantity_from_form'] = int(request.POST["quantity"])
    productx = Product.objects.get(id= int(request.POST["priceid"]))
    request.session['price_from_form'] = float(productx.price)
    request.session['total_charge'] = request.session['quantity_from_form'] * request.session['price_from_form']
    Order.objects.create(quantity_ordered=request.session['quantity_from_form'], total_price=request.session['total_charge'])
    print("Charging credit card...")
    return redirect('/check')

def check(request):
    context = {
        'quantity': request.session['quantity_from_form'],
        'price': request.session['price_from_form'],
        'total': request.session['total_charge']
    }
    print("Charging credit card...")
    return render(request, "store/checkout.html",context)

