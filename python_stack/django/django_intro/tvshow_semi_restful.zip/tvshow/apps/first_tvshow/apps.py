from django.apps import AppConfig


class FirstTvshowConfig(AppConfig):
    name = 'first_tvshow'
