from django.apps import AppConfig


class NinjaFarmConfig(AppConfig):
    name = 'ninja_farm'
