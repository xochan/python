from django.apps import AppConfig


class FirstQueryConfig(AppConfig):
    name = 'first_query'
