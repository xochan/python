from django.apps import AppConfig


class FirstWallConfig(AppConfig):
    name = 'first_wall'
