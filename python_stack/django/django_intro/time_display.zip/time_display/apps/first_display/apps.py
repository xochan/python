from django.apps import AppConfig


class FirstDisplayConfig(AppConfig):
    name = 'first_display'
